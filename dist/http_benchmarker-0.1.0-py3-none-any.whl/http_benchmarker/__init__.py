"""HTTP Benchmarker - A lightweight tool for load testing HTTP servers"""
__version__ = "0.1.0"
